import reflex as rx

from .state import State

# from .structure_user import User_State 



def workspace():
    return rx.box(
    rx.vstack(
    rx.hstack(
        rx.flex(
            rx.box(
                rx.text("Workspace 1", text_align="center"),
                width="20%",
                border="1px solid black",
                padding="20px",
                justify_content="center",
                align_items="center"
            ),
            rx.box(
                rx.text("Workspace 2", text_align="center"),
                width="20%",
                border="1px solid black",
                padding="20px",
                justify_content="center",
                align_items="center"
            ),
            rx.box(
                rx.text("Workspace 3", text_align="center"),
                width="20%",
                border="1px solid black",
                padding="20px",
                justify_content="center",
                align_items="center"
            ),
            width="100%",
            justify_content="space-between"
        ),
        width="100%",
    ),
    rx.button(
            "Create a new Workspace",
            color_scheme="green",
            size="3",
            margin_top="25px",
            #on_click=User_State.create_workspace,
            ),
    ),
    justify_content="center",
    )